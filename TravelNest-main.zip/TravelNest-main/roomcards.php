<div class="row py-3">
        <div class="col-lg-4 mb-4 d-flex justify-content-center align-items-center" >
            <div class="card" style="width: 100% !important; box-shadow: rgba(0, 0, 0, 0.25) 0px 25px 50px -12px;">
            <img src="../Hotel/images/Picsart_24-02-08_21-34-28-185.jpg" class="card-img-top" alt="...">  
          <div class="card-body" style="line-height: 1;">
            <h4 class="card-title d-flex justify-content-between align-items-center fw-bold">
            Hotel Setif Plus</span> <span class="fs-6">4.8 <i class="bi bi-star-fill text-primary"></i></span>
            </h4>
            <p style="font-size: 14px; font-weight:400;"><i class="bi text-primary bi-geo-alt-fill"></i> Algeria, Setif</p>
            <h3 data-original-price="68" class="card-text text-primary fw-bold price">
            68$<span class="" style="font-size:16px; color: black; font-weight: 300;">/night</span>
            </h3>
            
          </div>
          </div>
          </div>
          <div class="col-lg-4 mb-4 d-flex justify-content-center align-items-center" >
            <div class="card" style="width: 100% !important; box-shadow: rgba(0, 0, 0, 0.25) 0px 25px 50px -12px;">
            <img src="../Hotel/images/Picsart_24-02-08_21-46-09-563.jpg" class="card-img-top" alt="...">  
          <div class="card-body" style="line-height: 1;">
            <h4 class="card-title d-flex justify-content-between align-items-center fw-bold">Feldmilla Design Hotel
            </span> <span class="fs-6">4.5 <i class="bi bi-star-fill text-primary"></i></span>
            </h4>
            <p style="font-size: 14px; font-weight:400;"><i class="bi text-primary bi-geo-alt-fill"></i> Italy, Campo Tures</p>
            <h3 data-original-price="246" class="card-text text-primary fw-bold price">
            246$<span class="" style="font-size:16px; color: black; font-weight: 300;">/night</span>
            </h3>
            
          </div>
          </div>
          </div>
          <div class="col-lg-4 mb-4 d-flex justify-content-center align-items-center">
            <div class="card" style="width: 100% !important; box-shadow: rgba(0, 0, 0, 0.25) 0px 25px 50px -12px;">
            <img src="../Hotel/images/Picsart_24-02-08_21-47-12-791.jpg" class="card-img-top" alt="...">  
          <div class="card-body" style="line-height: 1;">
            <h4 class="card-title d-flex justify-content-between align-items-center fw-bold">
            Burj Al Arab Jumeirah</span> <span class="fs-6">4.8 <i class="bi bi-star-fill text-primary"></i></span>
            </h4>
            <p style="font-size: 14px; font-weight:400;"><i class="bi text-primary bi-geo-alt-fill"></i> Émirats arabes unis, Dubai</p>
            <h3 class="card-text text-primary fw-bold price" data-original-price="2938">
            2 938$<span class="" style="font-size:16px; color: black; font-weight: 300;">/night</span>
            </h3>
              
            
          </div>
          </div>
          </div>
  </div>


  <?php 



?>
<style>
  .icone-fs a{
   transition:  0.3s ;
  }
  .icone-fs a:hover{
    transform: scale(1.1) !important;
    
  }
</style>
<section id="contact" class="pb-5 mt-2" style="background-color: #f3f3f5">
      <div class="container px-4 text-center">
        <h1 class="mb-3">Reach Us</h1>
        <div class="row py-3 text-white text-center bs-1 bg-primary " style=" border-radius:10px; font-size: 18px">
          <div class="col border-left-md" style="white-space: nowrap !important;">
          <div class="row">
            <p> <i class="fa-solid fa-phone"></i> +213 555 555 555 </p>
          </div>
          <div class="row">
            <p><i class="fa-solid fa-envelope"></i> example@mail.com</p>
          </div>
          <div class="row">
            <P><i class="fa-solid fa-location-dot"></i> 123, Main Road, Your City</P>
            
          </div>
          <div class="row">
            <p><i class="fa-solid fa-clock"></i> Mon - Fri: 9:00 - 19:00</p>
          </div>
          </div>
          
          <div class="col icone-fs" style="display: flex; align-items: center; align-content: center; justify-content: center; letter-spacing: 4px; white-space: nowrap !important;">
            <p style="margin:0 !important;" class="icone-fs">
                <a href="#" class="text-white fb">
                  <i class="bi bi-facebook"></i>
                </a>
                <a href="#" class="text-white inst">
                    <i class="bi bi-instagram"></i>
                </a>
                <a href="#" class="text-white twtr">
                    <i class="bi bi-twitter"></i>
                </a>
            </p>
          </div>
        </div>
      </div>
    </section>
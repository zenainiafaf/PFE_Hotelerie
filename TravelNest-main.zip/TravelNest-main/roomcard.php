
    <div class="card mt-4 px-0" style="position:relative" >
  <div class="row g-0">
    <div class="col-md-4">
    <div id="carouselExampleFade" class="carousel slide carousel-fade">
  <div class="carousel-inner">
    <div class="carousel-item active" style="aspect-ratio: 16/10 !important;">
      <img src="images/hotelspic/472324895.jpg" class="d-block w-100 h-100" alt="...">
    </div>
    <div class="carousel-item" style="aspect-ratio: 16/10 !important;">
      <img src="images/hotelspic/57903161.jpg" class="d-block w-100 h-100" alt="...">
    </div>
    <div class="carousel-item" style="aspect-ratio: 16/10 !important;">
      <img src="images/suite-junior.jpg" class="d-block w-100 h-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    </div>
    <div class="col-md-8">
      <div class="card-body pb-0 pt-2 #carouselExampleFade">
        <h3 class="card-title m-0" style="font-weight: 600;">Hotel Alger Plus</h3>
        <p class="card-text m-0" style="font-size:12px">Algeria, Alger</p>
        <p class="card-text m-0"><small class="text-primary">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        </small></p>
        <p class="card-text m-0" style="font-size:12px">
        <i class="fa-solid fa-person-swimming text-primary"></i> Pool
        </p>
        <p class="card-text m-0" style="font-size:24px; color: white;">
        a333333333333333333333333333333333333333333333333333333333333333333
        </p>
      </div>
      <div class="card-footer text-black p-0 " style="margin-bottom: 8px; text-align: right; position:absolute; border: none !important; bottom: 0; right:0; margin-right:16px">
        <p class="card-text m-0 prix " style="font-size:24px; font-weight: 600; ">
        256$
        </p>
        <p class="card-text m-0 prix"  style="font-size:12px; ">
        68$/night
        </p>
        <p class="card-text m-0" style="font-size:12px; ">
        inluded tax and fees
        </p>

     </div>
     <div class="card-footer p-0  d-flex gap-1" style="position:absolute; margin-bottom: 8px; border: none !important; bottom: 0; margin-left:16px">
        <p class="card-text m-0 text-center py-1 px-2 d-flex align-items-center justify-content-center bg-primary rounded" style="color:white; font-weight:500; font-size:16px">
        9.6
        </p>
        <span class="card-text m-0" style="font-size:12px; font-weight: 500;">
        <p class="p-0 m-0"  >Excellent</p>
        <p class="p-0 m-0" >120 reviwes</p>
        </span>
     </div>
    </div>
  </div>
</div>










<footer class="bg-info text-white text-center py-3" id='footer'>
  <p>
    &copy; 2024 <span style="font-family: 'Orbitron', sans-serif !important; font-optical-sizing: auto; font-weight: 600; font-style: normal;">Travel<span class="text-primary">Nest</span></span>. All rights reserved.
  </p>
</footer>